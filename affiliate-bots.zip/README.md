
# Affiliate Bots

Minimal bot framework with a Puppeteer-based Twitter bot.

## Setup

1. Install dependencies:
   npm install

2. Run the Twitter bot:
   cd twitter-bot
   node twitter_bot.js
